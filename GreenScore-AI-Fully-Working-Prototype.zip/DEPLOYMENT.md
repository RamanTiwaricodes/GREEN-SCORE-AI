# GREENScore AI — Deployment Guide

This project is prepared for a simple public deployment:

- Frontend: Vercel
- Backend: Render (FastAPI)
- Database: Render PostgreSQL
- Source: GitHub

## 1. Push this project to GitHub

Keep `backend/` and `frontend/` in the same repository.
Do NOT commit `.env` files or API keys.

## 2. Deploy backend + database on Render

1. Open Render and choose **New → Blueprint**.
2. Connect the GitHub repository.
3. Render detects `render.yaml`.
4. Create the PostgreSQL database and `greenscore-ai-api` service.
5. Set `CORS_ORIGINS` to the final Vercel URL, for example:
   `https://greenscore-ai.vercel.app`
6. Add optional API keys only if the feature is enabled.
7. After deploy, open:
   `https://YOUR-BACKEND.onrender.com/docs`
   Also verify `https://YOUR-BACKEND.onrender.com/` returns `status: ONLINE`.

If `/docs` opens, the FastAPI backend is live.

## 3. Deploy frontend on Vercel

1. Import the same GitHub repository into Vercel.
2. Set **Root Directory** to `frontend`.
3. Framework preset: Vite.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Add environment variable:
   `VITE_API_URL=https://YOUR-BACKEND.onrender.com`
7. Deploy.

The existing `frontend/vercel.json` keeps client-side routes working.

## 4. Final CORS update

Copy the final Vercel URL into Render's `CORS_ORIGINS` environment variable and redeploy/restart the backend.

## 5. Test the public application

- Open the Vercel URL.
- Login using the demo credentials from README.
- Test dashboard, predictions, budget optimizer, simulator, citizen report, action workflow and impact verification.
- Open backend `/docs` separately to verify API availability.
- Verify `/api/weather/current`, `/api/air-quality/current`, and `/api/city/environment` return either live data or an explicitly labeled demo fallback.

## Important notes

- The app uses SQLite locally but Render production is configured for PostgreSQL.
- Database tables and seed data are initialized by the FastAPI startup lifecycle.
- Never put `OPENAI_API_KEY`, `OPENAQ_API_KEY`, database credentials or JWT secrets in frontend code.
- `VITE_API_URL` is public by design; it should contain only the backend base URL.
