import base64
import datetime
import hashlib
import hmac
import json
from typing import Optional

from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.core.config import settings

security_bearer = HTTPBearer(auto_error=False)


def _hash_pwd(password: str) -> str:
    """Portable deterministic password hash for the demo prototype.

    Production deployments should use Argon2/bcrypt with per-user salts. This
    project intentionally keeps authentication dependency-light for reliable
    hackathon deployment across environments.
    """
    salt = "greenscore_orbit_salt_2026"
    return hashlib.sha256((password + salt).encode("utf-8")).hexdigest()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hmac.compare_digest(_hash_pwd(plain_password), hashed_password)


def get_password_hash(password: str) -> str:
    return _hash_pwd(password)


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def create_access_token(data: dict, expires_delta: Optional[datetime.timedelta] = None) -> str:
    """Create a compact HS256 JWT without an external JWT package."""
    now = datetime.datetime.now(datetime.timezone.utc)
    expire = now + (expires_delta or datetime.timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    payload = dict(data)
    payload.update({"iat": int(now.timestamp()), "exp": int(expire.timestamp())})
    header = {"alg": settings.JWT_ALGORITHM, "typ": "JWT"}

    header_part = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    payload_part = _b64url_encode(json.dumps(payload, separators=(",", ":"), default=str).encode())
    signing_input = f"{header_part}.{payload_part}".encode()
    signature = hmac.new(settings.JWT_SECRET.encode(), signing_input, hashlib.sha256).digest()
    return f"{header_part}.{payload_part}.{_b64url_encode(signature)}"


def decode_token(token: str) -> Optional[dict]:
    try:
        header_part, payload_part, signature_part = token.split(".")
        signing_input = f"{header_part}.{payload_part}".encode()
        expected = hmac.new(settings.JWT_SECRET.encode(), signing_input, hashlib.sha256).digest()
        actual = _b64url_decode(signature_part)
        if not hmac.compare_digest(expected, actual):
            return None
        header = json.loads(_b64url_decode(header_part))
        if header.get("alg") != settings.JWT_ALGORITHM:
            return None
        payload = json.loads(_b64url_decode(payload_part))
        if int(payload.get("exp", 0)) < int(datetime.datetime.now(datetime.timezone.utc).timestamp()):
            return None
        return payload
    except (ValueError, TypeError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def get_current_user_optional(auth: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)) -> Optional[dict]:
    if not auth:
        return None
    return decode_token(auth.credentials)


def get_current_user(auth: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer)) -> dict:
    if not auth:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    payload = decode_token(auth.credentials)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return payload


def require_role(allowed_roles: list[str]):
    def role_checker(current_user: dict = Depends(get_current_user)):
        user_role = current_user.get("role", "CITIZEN")
        if user_role not in allowed_roles and user_role != "SUPER_ADMIN":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied for role: {user_role}. Required: {allowed_roles}"
            )
        return current_user
    return role_checker
